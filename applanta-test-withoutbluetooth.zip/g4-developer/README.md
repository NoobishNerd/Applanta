![Applanta Logo](https://cdn.discordapp.com/attachments/639847770093781022/788788141158825984/gradiente2.png)

### Aplicação Educacional e Musical Sobre Plantas

A Applanta é uma aplicação educacional que tem como objetivos principais criar uma forma divertida, única e musical de interagir com plantas e, dentro dessas interações, expor uma audiência jovem a um universo diferente dedicado à flora.

A função principal da app é permitir ao utilizador tocar música em conjunto com plantas. Foi proposto ao grupo criar algo que possa ser usado por mais que um utilizador ao mesmo tempo de forma a que todos possam ver as interações dos outros (semelhante ao website http://www.filipelopes.net/ ). Caso o utilizador esteja sozinho com uma planta seria possível tocar um dueto com ela e guardar as músicas assim criadas.

Será também possivel criar amizades com as plantas e listar estas amizades e as músicas criadas. Os utilizadores poderão também progredir a sua conta através de níveis e conquistas.

##### Realizado por José Santos | Luís Sampaio | Rui Gonçalves
